# kxmlparser
Rest-Framework Parser Convert xml to json

##Getting Started
#### Dependencies
You need Python 3.7 or later

You also need json and xmltodict packages available from PyPI, if you have pip just run:
pip install xmltodict

####Instalation
Clone this repo to your Local Machine using:
```
git clone https://github.com/k1k0borba/kxml2json.git
```

## Features
- File structure for PyPI packages
- Setup with package informations
- License example

